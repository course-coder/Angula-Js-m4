(function() {
    'use strict';

    angular.module('data', []);
})();
